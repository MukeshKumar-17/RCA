import { jsx, jsxs } from "react/jsx-runtime";
import React from "react";
export default function HistoricalView() {
  return /* @__PURE__ */ jsxs("div", { className: "p-margin max-w-[1400px] w-full mx-auto", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-8 flex items-end justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { className: "font-headline-lg text-on-surface uppercase mb-2", children: "Historical Incidents" }),
        /* @__PURE__ */ jsx("p", { className: "font-body-md text-on-surface-variant", children: "Database of past events and resolutions." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 bg-surface-container-lowest neo-border px-3 py-1.5 cursor-pointer hover:bg-surface-variant", children: [
          /* @__PURE__ */ jsx("span", { className: "font-label-mono uppercase", children: "Severity" }),
          /* @__PURE__ */ jsx("span", { className: "material-symbols-outlined text-[16px]", children: "expand_more" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 bg-surface-container-lowest neo-border px-3 py-1.5 cursor-pointer hover:bg-surface-variant", children: [
          /* @__PURE__ */ jsx("span", { className: "font-label-mono uppercase", children: "Date" }),
          /* @__PURE__ */ jsx("span", { className: "material-symbols-outlined text-[16px]", children: "expand_more" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 bg-surface-container-lowest neo-border px-3 py-1.5 cursor-pointer hover:bg-surface-variant", children: [
          /* @__PURE__ */ jsx("span", { className: "font-label-mono uppercase", children: "Service" }),
          /* @__PURE__ */ jsx("span", { className: "material-symbols-outlined text-[16px]", children: "expand_more" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "bg-surface-container-lowest neo-border flex flex-col", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[1fr_120px_120px_2fr_1.5fr_1fr] gap-4 p-4 border-b-[3px] border-on-surface bg-surface-variant font-label-bold uppercase tracking-wide text-xs", children: [
        /* @__PURE__ */ jsx("div", { className: "", children: "Incident" }),
        /* @__PURE__ */ jsx("div", { className: "", children: "Severity" }),
        /* @__PURE__ */ jsx("div", { className: "", children: "Match" }),
        /* @__PURE__ */ jsx("div", { className: "", children: "Root Cause" }),
        /* @__PURE__ */ jsx("div", { className: "", children: "Resolution" }),
        /* @__PURE__ */ jsx("div", { className: "", children: "Date / Owner" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[1fr_120px_120px_2fr_1.5fr_1fr] gap-4 p-4 border-b-[3px] border-on-surface hover:bg-[#E0F7FF] transition-colors items-center group cursor-pointer", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "font-label-bold text-on-surface", children: "INC-8492" }),
          /* @__PURE__ */ jsx("div", { className: "font-body-sm text-on-surface-variant truncate", children: "Redis Cache Eviction Spike" })
        ] }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "bg-brand-coral text-on-surface font-label-mono px-2 py-1 neo-border", children: "SEV-1" }) }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "text-brand-teal font-headline-sm", children: "94%" }) }),
        /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface-variant line-clamp-2", children: "Memory limit reached causing aggressive key eviction and latency." }),
        /* @__PURE__ */ jsxs("div", { className: "font-label-mono text-on-surface", children: [
          /* @__PURE__ */ jsx("span", { className: "bg-surface-dim px-1", children: "Config Rollback" }),
          " to v2.1"
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface", children: "Oct 12, 2023" }),
          /* @__PURE__ */ jsxs("div", { className: "font-body-sm text-outline flex items-center gap-1", children: [
            /* @__PURE__ */ jsx("span", { className: "material-symbols-outlined text-[14px]", children: "person" }),
            " J. Doe"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[1fr_120px_120px_2fr_1.5fr_1fr] gap-4 p-4 border-b-[3px] border-on-surface hover:bg-[#E0F7FF] transition-colors items-center group cursor-pointer", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "font-label-bold text-on-surface", children: "INC-8104" }),
          /* @__PURE__ */ jsx("div", { className: "font-body-sm text-on-surface-variant truncate", children: "API Gateway Timeout" })
        ] }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "bg-brand-yellow text-on-surface font-label-mono px-2 py-1 neo-border", children: "SEV-2" }) }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "text-brand-teal font-headline-sm", children: "78%" }) }),
        /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface-variant line-clamp-2", children: "Downstream service dependency failure caused thread pool exhaustion." }),
        /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface", children: /* @__PURE__ */ jsx("span", { className: "bg-surface-dim px-1", children: "Patched in v1.4.3" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface", children: "Sep 28, 2023" }),
          /* @__PURE__ */ jsxs("div", { className: "font-body-sm text-outline flex items-center gap-1", children: [
            /* @__PURE__ */ jsx("span", { className: "material-symbols-outlined text-[14px]", children: "person" }),
            " A. Smith"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[1fr_120px_120px_2fr_1.5fr_1fr] gap-4 p-4 border-b-[3px] border-on-surface hover:bg-[#E0F7FF] transition-colors items-center group cursor-pointer", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "font-label-bold text-on-surface", children: "INC-7933" }),
          /* @__PURE__ */ jsx("div", { className: "font-body-sm text-on-surface-variant truncate", children: "DB Connection Drain" })
        ] }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "bg-brand-coral text-on-surface font-label-mono px-2 py-1 neo-border", children: "SEV-1" }) }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "text-brand-teal font-headline-sm", children: "42%" }) }),
        /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface-variant line-clamp-2", children: "Unindexed query caused full table scan, locking connections." }),
        /* @__PURE__ */ jsxs("div", { className: "font-label-mono text-on-surface", children: [
          /* @__PURE__ */ jsx("span", { className: "bg-surface-dim px-1", children: "Index Added" }),
          " to users_tbl"
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface", children: "Aug 15, 2023" }),
          /* @__PURE__ */ jsxs("div", { className: "font-body-sm text-outline flex items-center gap-1", children: [
            /* @__PURE__ */ jsx("span", { className: "material-symbols-outlined text-[14px]", children: "person" }),
            " System"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[1fr_120px_120px_2fr_1.5fr_1fr] gap-4 p-4 hover:bg-[#E0F7FF] transition-colors items-center group cursor-pointer", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "font-label-bold text-on-surface", children: "INC-7650" }),
          /* @__PURE__ */ jsx("div", { className: "font-body-sm text-on-surface-variant truncate", children: "Payment Webhook Failure" })
        ] }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "bg-surface-dim text-on-surface font-label-mono px-2 py-1 neo-border", children: "SEV-3" }) }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "text-on-surface-variant font-headline-sm", children: "12%" }) }),
        /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface-variant line-clamp-2", children: "Third-party provider API rate limit exceeded during peak traffic." }),
        /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface", children: /* @__PURE__ */ jsx("span", { className: "bg-surface-dim px-1", children: "Retry Logic Update" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "font-label-mono text-on-surface", children: "Jul 02, 2023" }),
          /* @__PURE__ */ jsxs("div", { className: "font-body-sm text-outline flex items-center gap-1", children: [
            /* @__PURE__ */ jsx("span", { className: "material-symbols-outlined text-[14px]", children: "person" }),
            " K. Lee"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "mt-6 flex justify-center", children: /* @__PURE__ */ jsx("button", { className: "bg-surface-container-lowest text-on-surface font-label-bold uppercase py-2 px-6 neo-border neo-button transition-all", children: "Load More" }) })
  ] });
}
