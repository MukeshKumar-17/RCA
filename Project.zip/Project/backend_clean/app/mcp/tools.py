"""
MCP Tool Definitions
~~~~~~~~~~~~~~~~~~~~
High-level tool functions that the orchestrator calls during the
RCA pipeline. Each tool wraps local storage operations
and returns a structured result the agents can consume.

Tools
-----
search_historical_incidents : find similar past incidents in local store
save_incident_to_mcp       : persist a completed incident to local store
"""

import logging
from typing import Any

from app.mcp.local_store import store

logger = logging.getLogger(__name__)


# ── Tool: search historical incidents ──────────────────────────────────

async def search_historical_incidents(
    user_context: str,
    limit: int = 3,
) -> dict[str, Any]:
    """Search local store for similar past incidents.

    Called by the orchestrator between the specialist agents and the
    RCA agent so that historical intelligence informs root cause analysis.

    Parameters
    ----------
    user_context : str
        Free-text description of the current incident (title, symptoms, etc.)
    limit : int
        Maximum number of similar incidents to return.

    Returns
    -------
    dict
        ``{"matches": [...], "match_count": int, "search_query": str}``
        Each match contains ``id``, ``user_context``, and ``rca``.
    """
    logger.info("mcp_tool: searching historical incidents for '%s'", user_context[:80])

    matches = store.search(user_context, limit=limit)

    logger.info("mcp_tool: found %d historical matches", len(matches))

    return {
        "matches": matches,
        "match_count": len(matches),
        "search_query": user_context,
    }


# ── Tool: save incident to local store ────────────────────────────────

async def save_incident_to_mcp(
    incident_id: str,
    user_context: str,
    status: str,
    rca: dict | None,
    evidence_completeness: int = 0,
    confidence_ceiling: int | None = None,
    agent_outputs: dict | None = None,
) -> dict[str, Any]:
    """Persist a completed incident record to local store.

    Parameters
    ----------
    incident_id : str
        Unique incident identifier.
    user_context : str
        Incident title / description.
    status : str
        Pipeline status (COMPLETE, NEEDS_CLARIFICATION, etc.)
    rca : dict or None
        The full RCA output from the RCA agent.
    evidence_completeness : int
        Evidence completeness score (0–100).
    confidence_ceiling : int or None
        Maximum confidence the RCA can achieve given available evidence.
    agent_outputs : dict or None
        Raw outputs from the specialist agents.

    Returns
    -------
    dict
        ``{"success": bool, "id": str, "error": str|None}``
    """
    from datetime import datetime, timezone

    record = {
        "id": incident_id,
        "user_context": user_context or "Untitled incident",
        "status": status,
        "evidence_completeness": evidence_completeness,
        "confidence_ceiling": confidence_ceiling,
        "rca": rca,
        "agent_outputs": agent_outputs,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    try:
        store.save(record)
        logger.info("mcp_tool: saved incident %s to local store", incident_id)
        return {"success": True, "id": incident_id, "error": None}
    except Exception as exc:
        logger.error("mcp_tool: failed to save incident — %s", exc)
        return {"success": False, "id": incident_id, "error": str(exc)}


# ── Tool: get incident from local store ───────────────────────────────

async def get_incident_from_mcp(incident_id: str) -> dict[str, Any] | None:
    """Fetch a single incident by id from local store.

    Returns
    -------
    dict or None
        The incident record, or None if not found.
    """
    return store.get(incident_id)
