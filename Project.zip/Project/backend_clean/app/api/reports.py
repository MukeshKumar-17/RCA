"""
Reports Router
~~~~~~~~~~~~~~
Fetches completed RCA reports and similar historical incidents from local store.

Routes
------
GET /report/{id}              — fetch a full RCA report by incident id
GET /similar-incidents/{id}   — fetch similar historical incidents
"""

import logging

from fastapi import APIRouter, HTTPException

from app.mcp.local_store import store

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Reports"])


# ── GET /report/{id} ──────────────────────────────────────────────────
@router.get("/report/{incident_id}")
async def get_report(incident_id: str):
    """Fetch a completed incident report by its id.

    Returns the full RCA JSON plus evidence_completeness and status.
    Returns 404 if the incident is not found.
    """
    record = store.get(incident_id)

    if not record:
        raise HTTPException(
            status_code=404,
            detail=f"Incident '{incident_id}' not found.",
        )

    return {
        "id": record.get("id"),
        "user_context": record.get("user_context"),
        "status": record.get("status"),
        "evidence_completeness": record.get("evidence_completeness"),
        "confidence_ceiling": record.get("confidence_ceiling"),
        "rca": record.get("rca"),
        "agent_outputs": record.get("agent_outputs"),
        "created_at": record.get("created_at"),
    }


# ── GET /similar-incidents/{id} ───────────────────────────────────────
@router.get("/similar-incidents/{incident_id}")
async def get_similar_incidents(incident_id: str):
    """Fetch similar historical incidents for a given incident id.

    Looks up the incident's user_context from local store, then searches
    for similar completed incidents.
    Returns an array of matches with similarity context and resolutions.
    """
    record = store.get(incident_id)

    if not record:
        raise HTTPException(
            status_code=404,
            detail=f"Incident '{incident_id}' not found.",
        )

    user_context = record.get("user_context", "")

    # Search for similar incidents in our local store
    matches = store.search(user_context, limit=5)

    # Filter out the current incident from results
    matches = [m for m in matches if m.get("id") != incident_id]

    return {
        "incident_id": incident_id,
        "matches": matches,
        "match_count": len(matches),
        "source": "local_store",
    }
