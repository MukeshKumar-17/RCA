"""
Incidents Router
~~~~~~~~~~~~~~~~
Accepts raw incident data (logs, timeline, diff, user_context),
runs the full orchestrator pipeline, persists the result locally,
and returns the incident id + status.

Routes
------
POST /incidents — run full RCA pipeline and save locally
"""

import json
import logging
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional

from app.agents import orchestrator
from app.mcp.local_store import store

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Incidents"])


# ── Request schema ─────────────────────────────────────────────────────
class IncidentRequest(BaseModel):
    """Payload for creating and analysing an incident in one shot."""

    logs: str = Field(default="", description="Raw log text")
    timeline: str = Field(default="", description="Incident timeline description")
    diff: str = Field(default="", description="Git diff text")
    user_context: str = Field(
        default="",
        description="Free-text context: incident title, description, or notes",
    )
    incident_date: Optional[str] = Field(
        default=None,
        description="Incident date in YYYY-MM-DD format (optional)",
    )


# ── POST /incidents ────────────────────────────────────────────────────
@router.post("/incidents", status_code=201)
async def create_and_analyze_incident(payload: IncidentRequest):
    """Run the full RCA pipeline and persist the result locally.

    Steps
    -----
    1. Validate that at least one data source is provided.
    2. Run ``orchestrator.run()`` with the raw inputs.
    3. Save the complete result to the local store.
    4. Return the incident ``id`` and ``status``.
    """
    # ── Validate: at least one source must be non-empty ────────────────
    if not any([
        payload.logs.strip(),
        payload.timeline.strip(),
        payload.diff.strip(),
    ]):
        raise HTTPException(
            status_code=400,
            detail="At least one data source (logs, timeline, or diff) must be provided.",
        )

    # ── Run the orchestrator pipeline ──────────────────────────────────
    logger.info("incidents: starting orchestrator pipeline")
    try:
        result = await orchestrator.run(
            raw_logs=payload.logs,
            raw_timeline=payload.timeline,
            raw_diff=payload.diff,
            incident_date=payload.incident_date,
            user_context=payload.user_context,
        )
    except Exception as exc:
        logger.error("incidents: orchestrator failed — %s", exc)
        raise HTTPException(
            status_code=500,
            detail=f"Analysis pipeline failed: {exc}",
        )

    # ── Persist locally ────────────────────────────────────────────────
    incident_id = str(uuid.uuid4())
    status = result.get("status", "COMPLETE")

    record = {
        "id": incident_id,
        "user_context": payload.user_context or "Untitled incident",
        "status": status,
        "evidence_completeness": result.get("evidence_completeness", 0),
        "confidence_ceiling": result.get("confidence_ceiling"),
        "rca": result.get("rca"),
        "agent_outputs": result.get("agent_outputs"),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    store.save(record)
    logger.info("incidents: saved locally — id=%s", incident_id)

    return {
        "id": incident_id,
        "status": status,
        "evidence_completeness": result.get("evidence_completeness"),
    }
